<div class="content-wrapper">
    <section class="content">
        <div class="row">
			<div class="col-sm-12">
				<div class="error-page">
				    <h2 class="headline text-red">400</h2>
				    <div class="error-content">
				        <h3><i class="fa fa-warning text-red"></i> Oops! Page not found.</h3>
				        <p>We will work on fixing that right away.Meanwhile, you may <a href="<?=base_url('dasbor')?>">return to dashboard</a> or try using the search form.</p>
				    </div>
				</div>
			</div>
		</div>
	</section>
</div>