<div class="content-wrapper">
    <section class="content-header">
		<h1>Log Izin</h1>
		<ol class="breadcrumb">
            <li><a href="<?=base_url('dashboard/index')?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
			<li class="active">Log Izin</li>
		</ol>
    </section>
    <section class="content">
        <div class="box box-mytheme">
            <?php if(permissionChecker('permissionlog_add')) { ?>
            <div class="box-header">
                <a href="<?=base_url('permissionlog/add')?>" class="btn btn-inline btn-mytheme btn-md"><i class="fa fa-plus"></i> Tambah Log Izin</a>
            </div>
            <?php } ?>
            <div class="box-body">
                <div id="hide-table">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama Log</th>
                                <th>Deskripsi</th>
                                <th>Status</th>
                                <?php if(permissionChecker('permissionlog_edit') || permissionChecker('permissionlog_delete')) { ?>
                                    <th>Aksi</th>
                                <?php } ?>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $i=0; if(calculate($permissionlogs)) { foreach($permissionlogs as $permissionlog) { $i++; ?>
                            <tr>
                                <td data-title="#"><?=$i?></td>
                                <td data-title="Nama Log"><?=$permissionlog->name?></td>
                                <td data-title="Deskripsi"><?=$permissionlog->description?></td>
                                <td data-title="Status"><?=$permissionlog->active?></td>
                                <?php if(permissionChecker('permissionlog_edit') || permissionChecker('permissionlog_delete')) { ?>
                                    <td data-title="Aksi">
                                        <?=btn_edit('permissionlog/edit/'.$permissionlog->permissionlogID, 'Edit')?>
                                        <?=btn_delete('permissionlog/delete/'.$permissionlog->permissionlogID, 'Delete')?>
                                    </td>
                                <?php } ?>
                            </tr>
                          <?php } } ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>#</th>
                                <th>Nama Log</th>
                                <th>Deskripsi</th>
                                <th>Status</th>
                                <?php if(permissionChecker('permissionlog_edit') || permissionChecker('permissionlog_delete')) { ?>
                                    <th>Aksi</th>
                                <?php } ?>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>