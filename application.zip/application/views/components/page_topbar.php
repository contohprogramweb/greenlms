<header class="main-header">
    <!-- Logo -->
    <a href="<?=base_url('/dashboard')?>" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b><?=character_limiter($pengaturan_umum->sitename,3)?></b></span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b><?=$pengaturan_umum->sitename?></b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" peran="button">
            <span class="sr-only">Toggle navigation</span>
        </a>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <?php if($pengaturan_umum->frontend == 1) { ?>
                	<li class="dropdown tasks-menu">
                		<a href="<?=base_url('/')?>" target="_blank" title="View Frontend" aria-expanded="true">
    		              <i class="fa fa-globe"></i>
    		            </a>
                    </li>
                <?php } ?>
                <li class="dropdown tasks-menu" style="display:none;">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <?php $language = $this->session->userdata("language"); ?>
                    <img class="languageimage" src="<?=base_url("uploads/language/$language.png")?>" alt="">
                    <span class="label label-danger">2</span>
                  </a>
                  <ul class="dropdown-menu">
                    <li class="header">Please select your language</li>
                    <li>
                      <ul class='menu'>
                        <li>
                          <a href="<?=base_url('Dasbor/langswitch/indonesia')?>">
                            <h3>
                                <img class="languageimage" src="<?=base_url('uploads/language/indonesia.png')?>" alt="">
                                Indonesia <?=$language=='indonesia' ? "<i class='fa fa-check'></i>" : ""?>
                            </h3>
                          </a>
                        </li>
                        
                        <li>
                          <a href="<?=base_url('Dasbor/langswitch/english')?>">
                            <h3>
                                <img class="languageimage" src="<?=base_url('uploads/language/english.png')?>" alt="">
                                English <?=$language=='english' ? "<i class='fa fa-check'></i>" : ""?>
                            </h3>
                          </a>
                        </li>
                        
                        
                      </ul>
                    </li>
                  </ul>
                </li>
                <!-- user Account: style can be found in dropdown.less -->
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="<?=profile_img($this->session->userdata('foto'))?>" class="user-image" alt="user Image">
                      <span class="hidden-xs"><?=$this->session->userdata('nama')?></span>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- user image -->
                        <li class="user-header">
                            <img src="<?=profile_img($this->session->userdata('foto'))?>" class="img-circle" alt="user Image">
                            <p><?=$this->session->userdata('nama')?> - <?=$this->session->userdata('peran')?><small> Anggota sejak - <?=date('d F Y',strtotime($this->session->userdata('joinningdate')))?></small></p>
                        </li>
                        <!-- Menu Footer-->
                        <li class="user-footer">
                            <div class="pull-left">
                                <a href="<?=base_url('Profil/index')?>" class="btn btn-default btn-flat">Profile</a>
                            </div>
                            <div class="pull-right">
                                <a href="<?=base_url('Masuk/logout')?>" class="btn btn-default btn-flat">Sign out</a>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>